import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class Main {
    List<Square> growing= squares.stream()
            .sorted(Comparator.comparingDouble(Rectangle::getArea))
            .collect(Collectors.toList())

    List<Square> bigger = squares.stream()
            .filter(s -> s.getArea() < s.getPerimeter())
            .collect(Collectors.toList());

    List<Square> decreasing = squares.stream()
            .sorted(Comparator.comparingDouble(Rectangle::getPerimeter)
                    .reversed())
            .collect(Collectors.toList());

    double average = Rectangles.stream().mapToDouble(Rectangle::getPerimeter).average().getAsDouble();

}
